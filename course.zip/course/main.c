/**
 * @mainpage Basic of Mathematic
 * Generate the course called Basic of mathematic and print its infomation
 * @file main.c
 * @author your name (you@domain.com)
 * @brief 
 * @version 0.1
 * @date 2022-04-06
 * 
 * @copyright Copyright (c) 2022
 * 
 */
 
#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"
/**
 * @brief The main function generate the course code MATH101 and the name is Basic of mathematics
 * which enrolled 20 students
 * @file main.c
 * 
 * @return int 
 */
int main()
{
  srand((unsigned) time(NULL));
/**
 *give the name of the course and the code of the function
 * 
 */
  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");
/**
 *generate 20 students with 8 grades into the course.
 * 
 */
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  print_course(MATH101);
/**
 *his generate a space of student and store the top student and print the info of him/her.
 * 
 */
  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);
/**
 * create the int total_passing to store the number of people passing
 * Then print the student who pass.
 * 
 */
  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}