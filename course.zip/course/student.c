/**
 * @file student.c
 * @author Guanhua(documented by)
 * @brief This code is to add grade to certian students, take average grades of a student, print a student info
 * and generate a new student.
 * The student.h include the info of students.
 * @version 0.1
 * @date 2022-04-06
 * @copyright Copyright (c) 2022
 * 
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"
/**
 * @brief The function is use to add the grades to a student.
 * 
 * @param student  input the student pointer
 * @param grade  input the grade of student
 */
void add_grade(Student* student, double grade)
{/**
 * @brief for number of grades not for index, so +1
 * 
 */
  student->num_grades++;
  /**
   * @brief because only one student and afraid malloc will remain staff, so use calloc.
   * 
   */
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));
  else 
  {/**
   * @brief When student have multiple grades, realloc the grades(if num of grades changes)
   * 
   */
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);
  }
  /**
   * @brief -1 because this is for index, substract the extra 1.
   * 
   */
  student->grades[student->num_grades - 1] = grade;
}
/**
 * @brief This function is to take students all the grades and return the average of the grade
 * 
 * @param student student pointer
 * @return double The average grades
 */
double average(Student* student)
{
  if (student->num_grades == 0) return 0;

  double total = 0;
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];///add all the grade together
  return total / ((double) student->num_grades);
}
/**
 * @brief print the infomation of the student.
 * 
 * @param student 
 */
void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}
/**
 * @brief This function will generate a random student.
 * @param grades 
 * @return Student* 
 */
Student* generate_random_student(int grades)
{
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
///allocate the memory of one student
  Student *new_student = calloc(1, sizeof(Student));

  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);
///genarate the student id
  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';

  for (int i = 0; i < grades; i++) 
  {///get the random grade of student between 25 to 99.
    add_grade(new_student, (double) (25 + (rand() % 75))); 
  }

  return new_student;
}