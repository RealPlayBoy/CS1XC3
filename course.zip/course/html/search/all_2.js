var searchData=
[
  ['basic_20of_20mathematic_0',['Basic of Mathematic',['../index.html',1,'']]]
];
